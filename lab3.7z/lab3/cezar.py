def cezar(text, krok):
        alf_UA = "абвгґдуєжзиіїйкльмншщпрстуфхцчшщьюяабвгґдуєжзиіїйкльмншщпрстуфхцчшщьюяАБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯАБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯabsdefghijklmnopqrstuvwxyzabsdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWABCDEFGHIJKLMNOPQRSTUVW1234567890"
        step = krok #
        message = text #
        result = "" #Результат шифру
        for i in message:
            cell = alf_UA.find(i) #Знаходження по алфавіту
            new_cell = cell + step # Рез
            if i in alf_UA:
                result += alf_UA[new_cell]#
            else:
                result += i#
        return result


print(cezar(input(), 1))

