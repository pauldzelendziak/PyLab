while True:
    operation = input("Виберіть операцію(a/b): ")
    if operation == "a":
        l = []
        x = input("ВВедіть текст :")
        for i in range(len(x)):
          if x[i] not in l and x[i] not in "." ",": # Виключення для ,.
              l.append(x[i])# + буква в масс
              l.append(x.count(x[i])) # рахування
        print(l)
        continue
    elif operation == "b":
        t = input("ВВедіть текст : ").split(" ")
        mass = []
        for j in t:
            if len(j) >= 3 and str.lower(j) not in mass: # ВИключення, якщо введено менше 3 символів видавало пустий масив
                mass.append(str.lower(j))
        print(sorted(mass))