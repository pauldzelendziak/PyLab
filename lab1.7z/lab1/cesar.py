while True:
    alf_EU = "absdefghijklmnopqrstuvwxyzabsdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWABCDEFGH123IJKLMNOPQRSTUVWabsdefghijklmnopqrstuvwxyzabsdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWABCDEFGHIJKLMNOPQRSTUVWабвгґдуєжзиіїйкльмншщпрстуфхцчшщьюяабвгґдуєжзиіїйкльмншщпрстуфхцчшщьюяАБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯАБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯ12345678901234567890"
    step = int(input("Enter key: "))
    message = input("Enter symbols : ")
    result = ""
    for i in message:
        res = alf_EU.find(i)
        nc = res + step
        if i in alf_EU:
            result += alf_EU[nc]
    print(result)
